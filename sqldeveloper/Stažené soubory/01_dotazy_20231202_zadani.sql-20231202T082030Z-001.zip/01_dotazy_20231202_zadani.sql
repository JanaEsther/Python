-- Najdi TOP 100 prodejů podle příjmů a k nim příslušné informace z tabulky Cities.
-- spojení uděláme pomocí celého názvu tabulek

-- můžeme použít alias pro tabulky. info: v Oracle není v aliasu u tabulek AS

-- také můžeme vybrat jen některéí sloupce

-- Jaké jsou tržby přes jednotlivé regiony 

-- Najdi 5 nejúspěšnějších měst v počtu prodejů za první kvartál roku 2014. 

-- Kolik různorodých produktů se prodalo v každém z měst? Zobraz i města, kde se neprodal žádný výrobek.

-- Najdi prodeje pro město se zip 33906 a zjisti o jaké jde mesto

-- Kolik různorodých produktů se nikdy neprodalo?

/* Samostatná práce */
-- Najděte v jednotlivých kategoriích počty výrobků, které se nikdy nepodařilo prodat.

-- Jaká byla výše příjmů v roce 2015 v rozpadu na měsíce? Zajímají nás všechny měsíce (i ty, kde nenastaly žádné příjmy).

/* Společná práce */
-- Vytvoř tabulku Cities2 jako kopii tabulky Cities

-- vložení záznamu do tabulky Cities2
insert into Cities2 (Zip, City, State, Region, District, Country)
values (33906,'Klatovy, CZE',null,'Západočeský kraj','Pražská','CZE');

-- Vytvoř tabulku pro prodeje za mesto se zip kódem 33906 (použij tabulku z předchozího příkladu)

-- Vytvoř tabulku Mesta s touto strukturou
-- Psc : INTEGER
-- Nazev: VARCHAR(100)
-- Kraj: VARCHAR(100)
-- Zeme: VARCHAR(20)

-- Vlož do tabulky záznam přímo
INSERT INTO Mesta (Psc, Nazev, Kraj, zeme)
VALUES (33701, 'Rokycany, CZE', 'Západočeský kraj', 'CZE');


-- vložení záznamu do tabulky jako select

/* Samostatná práce */
-- Vytvoř tabulku DistrictRevenueYear jako přehled celkového výdělku po letech pro jednotlivé Districts (spojení 3 tabulek)

-- BONUS: Vytvoř tabulku jednotlivých dnů za třetí kvartál roku 2014, ke každému dni zjisti celkovou tržbu za den, počet prodejů a počet prodaných kusů

/* Společná práce */
-- Vytvoř pohled pro prodeje za mesto se zip kódem 33906

-- Vytvoř tabulku Mesta2 s touto strukturou, IdMesta definuj jako primarni klic a PSC jako jedinečnou hodnotu
-- IdMesta: INTEGER
-- Psc : INTEGER
-- Nazev: VARCHAR(100)
-- Kraj: VARCHAR(100)
-- Zeme: VARCHAR(20)

-- Vlož do tabulky několik záznamů (ověření chování podmínek)

-- Vytvoř tabulku NewProdeje s touto strukturou, IdMesta definuj jako cizi klic do tabulky Mesta a ProductID s povinností vyplnění
-- ProductID: INTEGER,
-- Datum: DATETIME,
-- IdMesta: INTEGER,
-- Kusu: Integer,
-- Trzba: NUMERIC (38, 4), 

-- Vlož do tabulky několik záznamů (ověření chování podmínek)

/* Samostatná práce */
-- Vytvořte tabulku ManufacturerQuarterSales s následující strukturou a omezeními
--	ManufacturerID INTEGER
--	Quarter Varchar(50)
--	PocetKusu INTEGER
--	Trzba NUMERIC (38, 4)
-- Omezení: 
-- ManufacturerID bude definován jako cizí klíč v tabulce manufacturers
-- Quarter musí být vždy vyplněno

-- Do vytvořené tabulky vložte po jednotlivých dodavatelech (manufacturerID) počet prodaných kusů a utržených peněz rozdělené na kvartály (nápověda - spojení 3 nebo 4 tabulek)

-- BONUS: Vytvořte pohled v kterém bude informace o jednotlivých státech a v nich počty jedinečných prodaných výrobků (productid).	

-- priklad na ziskani mesice z datumu

-- jaký je ascii kod znaku 'A'

-- spojeni retezcu

-- Z tabulky Cities vyberte jedinečné záznamy, které vzniknou spojením sloupců Region a State

-- delka retezce 'Ahoj Czechitas'

-- Zjistěte délku nejdelšího názvu města a které to je

-- získejte první 4 znaky z řetězce 'Ahoj Czechitas'

-- zjistěte pozici řetězce 'Cze' v řetězci 'Ahoj Czechitas'

-- Nahraďte Ahoj za Hello v řetězci 'Ahoj Czechitas'

-- Odstranění mezer

-- pomocí regulárního výrazu vybrat jen čísla z 'cislo 120'

-- pomocí regulárního výrazu vybrat jen pismena z 'cislo 120'

-- globalni promene

-- přidání 3 měsíců k aktualnímu datu

-- ověření, že funguej správně i při konci měsíce

-- jaká bude nejbližší středa

-- začátek roku pro aktuální datum

-- počet měsíců od začátku roku

-- CASE
-- Rozděl tržby do kategorií malá (do 300), střední (300 - 750) a velká (nad 750) a zjisti počty  těchto kategoriích

/* SAMOSTATNÁ PRÁCE */
-- Rozděl produkty podle ceny od 0 do 900 po 300 do kategoií 300(0-300), 600(300-600), 900(600-900), a nad900 a zjisti kolik výrobků je v které kategorii

-- BONUS: Z předchozího příkladu vytvoř pohled ve kterém bude ProductID, výrobce a cenovaHladina

-- BONUS: Spojenim prodeju a vytvořeného pohledu zjisti jak se výrobky v jednotlivých kategoriích prodávaly

